<?php
    $plugin->version = 2017032800;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
