<?php
    $plugin->version = 2017032400;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
