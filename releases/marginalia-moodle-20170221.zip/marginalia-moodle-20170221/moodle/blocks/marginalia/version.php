<?php
    $plugin->version = 2017020700;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
