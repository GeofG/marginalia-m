<?php
    $plugin->version = 2019031500;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
