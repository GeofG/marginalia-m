<?php
    $plugin->version = 2016070400;
    $plugin->requires = 2015111603;
	$plugin->component = 'block_marginalia';
