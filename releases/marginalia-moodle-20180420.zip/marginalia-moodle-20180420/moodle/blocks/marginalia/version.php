<?php
    $plugin->version = 2018041800;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
