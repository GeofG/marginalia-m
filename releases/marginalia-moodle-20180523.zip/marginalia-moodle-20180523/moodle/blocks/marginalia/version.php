<?php
    $plugin->version = 2017043000;
    $plugin->requires = 2014111003;
	$plugin->component = 'block_marginalia';
